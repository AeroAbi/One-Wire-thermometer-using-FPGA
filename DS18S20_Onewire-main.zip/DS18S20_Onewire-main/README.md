# DS18S20_Onewire
one wire temperature measurement in VHDL
